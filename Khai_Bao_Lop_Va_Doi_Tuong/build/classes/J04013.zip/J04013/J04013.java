package J04013;

import java.util.Scanner;

public class J04013 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println(new ThiSinh(sc.nextLine(), sc.nextLine(), Double.parseDouble(sc.nextLine()), 
                Double.parseDouble(sc.nextLine()), Double.parseDouble(sc.nextLine())));
        
    }
    
}
