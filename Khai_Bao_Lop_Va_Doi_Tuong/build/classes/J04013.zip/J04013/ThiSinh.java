
package J04013;

public class ThiSinh {
    
    private static double[] level = {0.0, 0.5, 1.0, 2.5};

    private String ID, name, status;
    private Double toan, ly, hoa, sum, uutien, sum1;

    public ThiSinh(String ID, String name, Double toan, Double ly, Double hoa) {
        this.ID = ID;
        this.name = name;
        this.toan = toan;
        this.ly = ly;
        this.hoa = hoa;
        
        this.uutien = level[Integer.parseInt(ID.substring(2,3))];
        
        this.sum = 2*this.toan + this.ly + this.hoa;
        this.sum1 = this.sum + this.uutien;
        this.status = (sum1 >= 24) ? "TRUNG TUYEN" : "TRUOT";
    }

    @Override
    public String toString() {
        return ID + " " + name + " " + (uutien.intValue() == uutien ? uutien.intValue() : String.format("%.1f", uutien)) + " " +
                (sum.intValue() == sum ? sum.intValue() : String.format("%.1f", sum)) + " " +status;
    }
    
    
    
}
