package J04014;

public class PhanSo {

    private long tuSo, mauSo;
    
    private static long gcd(long a, long b){
        while(a*b != 0){
            if(a > b) a%=b;
            else b%=a;
        }
        return a+b;
    }

    public PhanSo(long tuSo, long mauSo) {
        this.tuSo = tuSo;
        this.mauSo = mauSo;
    }
    
    public static PhanSo add(PhanSo a, PhanSo b){
        long lcm_1 = (a.mauSo * b.mauSo) / gcd(a.mauSo, b.mauSo);
        long tuSo_1 = a.tuSo * (lcm_1 / a.mauSo) + b.tuSo * (lcm_1 / b.mauSo);
        long gcd_1 = gcd(tuSo_1, lcm_1);
        return new PhanSo(tuSo_1 / gcd_1, lcm_1 / gcd_1);
    }
    
    public static PhanSo mul(PhanSo a, PhanSo b){
        return new PhanSo(a.tuSo * b.tuSo, a.mauSo * b.mauSo);
    }

    @Override
    public String toString() {
        return tuSo + "/" + mauSo;
    }
    
}
