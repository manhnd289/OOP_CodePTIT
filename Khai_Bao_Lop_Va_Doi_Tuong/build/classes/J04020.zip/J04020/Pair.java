package J04020;

public class Pair <T,V> {

    private T a;
    private V b;

    public Pair(T a, V b) {
        this.a = a;
        this.b = b;
    }
    
    public boolean isPrime(){
        for(int i = 2 ; i < Math.sqrt((int)a) ; i++){
            if ((int)a % i == 0) return false;
        }
        for(int i = 2 ; i < Math.sqrt((int)b) ; i++){
            if ((int)b % i == 0) return false;
        }
        return (int)a >= 2 && (int)b >= 2;
    }

    @Override
    public String toString() {
        return a + " " + b;
    }
    
    
}
