package J04005;

import java.util.Scanner;

public class J04005 {

    public static void main(String[] args) {
        
        Scanner sc = new Scanner(System.in);
        System.out.println(new SinhVien(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine()));
        
    }
    
}
