package J07009;

import java.util.ArrayList;
import java.util.Collections;

public class IntSet {

    private int[] arr;
    private int len;

    public IntSet(int[] arr) {
        this.arr = arr;
    }
    
    public IntSet intersection(IntSet a){
        ArrayList<Integer> tmp = new ArrayList<>();
        int[] cnt = new int[1005];
        for(Integer item : arr){
            cnt[item] += 1;
        }
        for(Integer item : a.arr){
            cnt[item] += 1;
        }
        for(int i = 0 ; i < 1001 ; i++){
            if(cnt[i] >= 2) tmp.add(i);
        }
        int[] tmp1 = new int[tmp.size()];
        for(int i = 0 ; i < tmp.size() ; i++){
            tmp1[i] = tmp.get(i);
        }
        IntSet res = new IntSet(tmp1);
        return res;
    }

    @Override
    public String toString() {
        for(int i = 0 ; i < arr.length ; i++){
            System.out.print(arr[i] + " ");
        }
        return "";
    }
}

