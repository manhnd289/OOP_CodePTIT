package J05011;

public class KhachHang implements Comparable<KhachHang>{

    private String name, Id;
    private Integer arrivingHour, arrivingMinute;
    private Integer leavingHour, leavingMinute;
    private Integer total_Time;

    public KhachHang(String Id, String name, String arrivingTime, String leavingTime) {
        this.name = name;
        this.Id = Id;
        this.arrivingHour = Integer.valueOf(arrivingTime.substring(0,2));
        this.arrivingMinute = Integer.valueOf(arrivingTime.substring(3));
        this.leavingHour = Integer.valueOf(leavingTime.substring(0,2));
        this.leavingMinute = Integer.valueOf(leavingTime.substring(3));
        this.total_Time = this.leavingHour*60 + this.leavingMinute - (this.arrivingHour*60+this.arrivingMinute);
    }

    @Override
    public String toString() {
        return Id + " " + name + " " + this.total_Time/60 + " gio " + this.total_Time%60 + " phut";
    }

    @Override
    public int compareTo(KhachHang o) {
        return o.total_Time.compareTo(total_Time);
    }
    
    
    
}
