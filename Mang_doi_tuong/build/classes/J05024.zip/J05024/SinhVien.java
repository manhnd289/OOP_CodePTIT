package J05024;

public class SinhVien {

    private String Id,name,lop,email,carrer;

    public SinhVien(String Id, String name, String lop, String email) {
        this.Id = Id;
        this.name = name;
        this.lop = lop;
        this.email = email;
        if(this.Id.substring(3,7).equals("DCKT")) this.carrer = "KE TOAN";
        else if(this.Id.substring(3,7).equals("DCCN") && this.lop.charAt(0)!='E') this.carrer = "CONG NGHE THONG TIN";
        else if(this.Id.substring(3,7).equals("DCAT") && this.lop.charAt(0)!='E') this.carrer = "AN TOAN THONG TIN";
        else if(this.Id.substring(3,7).equals("DCVT")) this.carrer = "VIEN THONG";
        else if(this.Id.substring(3,7).equals("DCDT")) this.carrer = "DIEN TU";
        else this.carrer = "";
    }

    @Override
    public String toString() {
        return Id + " " + name + " " + lop + " " + email;
    }

    public String getCarrer() {
        return carrer;
    }
    
}
