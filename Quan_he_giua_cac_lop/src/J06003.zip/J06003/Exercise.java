package J06003;

import java.util.ArrayList;

public class Exercise {

    private String name;
    private int Id;
    public static ArrayList<Student>[] arr = new ArrayList[105];
    
    public static void init(){
        for(int i = 0 ; i < 105 ; i++){
            arr[i] = new ArrayList<>();
        }
    }

    public Exercise(String name) {
        this.name = name;
    }
    
}
