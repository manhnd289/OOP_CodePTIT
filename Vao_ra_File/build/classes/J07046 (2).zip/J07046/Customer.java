package J07046;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class Customer implements Comparable<Customer>{

    private String id, name, idRoom;
    private long timeElapsed;
    
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public Customer(String id, String name, String idRoom, String start, String end) throws ParseException {
        this.id = id;
        this.name = name;
        this.idRoom = idRoom;
        Date date1 = sdf.parse(start);
        Date date2 = sdf.parse(end);
        this.timeElapsed = TimeUnit.MILLISECONDS.toDays(date2.getTime() - date1.getTime());
    }

    @Override
    public String toString() {
        return id + " " + name + " " + idRoom + " " + timeElapsed;
    }

    @Override
    public int compareTo(Customer o) {
        return (int)(o.timeElapsed - timeElapsed);
    }
    
    
    
}
