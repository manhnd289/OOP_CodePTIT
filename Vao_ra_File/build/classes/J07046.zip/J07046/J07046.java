package J07046;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07046 {

    public static void main(String[] args) throws FileNotFoundException, ParseException {
        
        Scanner sc = new Scanner(new File("KHACH.in"));
        int t = sc.nextInt(); sc.nextLine();
        KhachHang kh;
        int cnt = 1;
        ArrayList<KhachHang> arr = new ArrayList<>();
        
        while(t-- > 0){
            kh = new KhachHang(String.format("KH%02d",cnt++), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(kh);
        }
        Collections.sort(arr);
        for(KhachHang item : arr) System.out.println(item);
        
    }
    
}
