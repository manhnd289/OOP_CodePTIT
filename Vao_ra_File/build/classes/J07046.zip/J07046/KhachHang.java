package J07046;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class KhachHang implements Comparable<KhachHang>{

    private String ID, name, IDroom;
    private long ElapsedTime;
    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    public KhachHang(String ID, String name, String IDroom, String ArrvingTime, String LeavingTime) throws ParseException {
        this.ID = ID;
        this.name = name;
        this.IDroom = IDroom;
//        if(!ArrvingTime.equals(LeavingTime)){
//            Date date1 = sdf.parse(ArrvingTime);
//            Date date2 = sdf.parse(LeavingTime);
//            this.ElapsedTime = TimeUnit.MILLISECONDS.toDays(date2.getTime()-date1.getTime());
//        }else this.ElapsedTime = 0;
        Date date1 = sdf.parse(ArrvingTime);
        Date date2 = sdf.parse(LeavingTime);
        this.ElapsedTime = TimeUnit.MILLISECONDS.toDays(date2.getTime()-date1.getTime());
    }

    @Override
    public String toString() {
        return ID + " " + name + " " + IDroom + " " + ElapsedTime;
    }

    @Override
    public int compareTo(KhachHang o) {
        return (int)(o.ElapsedTime - ElapsedTime);
    }
    
}
