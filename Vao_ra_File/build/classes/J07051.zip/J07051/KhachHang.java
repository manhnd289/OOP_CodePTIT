package J07051;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class KhachHang implements Comparable<KhachHang>{
    
    private static int[] fee = {0,25,34,50,80};
    
    private static String chuanHoa(String inp){
        String[] tmp = inp.trim().toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder("");
        for(String item : tmp){
            sb.append(item.substring(0,1).toUpperCase()+item.substring(1));
            sb.append(" ");
        }
        return sb.toString();
    }

    private String ID, name, IDroom;
    private long price, elapsedTime;
    
    SimpleDateFormat sdf  = new SimpleDateFormat("dd/MM/yyyy");

    public KhachHang(String ID, String name, String IDroom, String arivingTime, String leavingTime, String price) throws ParseException {
        this.ID = ID;
        this.name = chuanHoa(name);
        this.IDroom = IDroom;
        Date date1 = sdf.parse(arivingTime);
        Date date2 = sdf.parse(leavingTime);
        this.elapsedTime = TimeUnit.MILLISECONDS.toDays(date2.getTime() - date1.getTime())+1;
        this.price = fee[Integer.parseInt(IDroom.substring(0,1))] * this.elapsedTime + Integer.parseInt(price);
    }

    @Override
    public String toString() {
        return ID + " " + name + " " + IDroom + " " + elapsedTime + " " + price;
    }

    @Override
    public int compareTo(KhachHang o) {
        return (int)(o.price - price);
    }
    
    
    
    
    
}
