package J07052;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07052 {

    public static void main(String[] args) throws FileNotFoundException {
        
        Scanner sc = new Scanner(new File("THISINH.in"));
        int t = sc.nextInt(); sc.nextLine();
        int n = t;
        ThiSinh ts;
        ArrayList<ThiSinh> arr = new ArrayList<>();
        
        while(t-- > 0){
            ts = new ThiSinh(sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(ts);
        }
        Collections.sort(arr);
        int chitieu = sc.nextInt();
        double diemchuan = 0;
        
        if(chitieu >= n) diemchuan = arr.get(n-1).getTotalMark();
        else diemchuan = arr.get(chitieu-1).getTotalMark();
        
        System.out.printf("%.1f\n",diemchuan);
        for(ThiSinh item : arr){
            System.out.print(item + " ");
            if(item.getTotalMark() >= diemchuan) System.out.println("TRUNG TUYEN");
            else System.out.println("TRUOT");
        }
        
    }
    
}
