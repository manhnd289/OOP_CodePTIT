package J07052;

public class ThiSinh implements Comparable<ThiSinh>{
    
    private static double[] level = {0,0.5,1.0,2.5};

    private String ID, name;
    private Double totalMark, uutien;
    
    private static String chuanHoa(String inp){
        String[] tmp = inp.trim().toLowerCase().split("\\s+");
        StringBuilder sb = new StringBuilder("");
        for(String item : tmp){
            sb.append(item.substring(0,1).toUpperCase());
            sb.append(item.substring(1));
            sb.append(" ");
        }
        return sb.toString().trim();
    }

    public ThiSinh(String ID, String name, String mark1, String mark2, String mark3) {
        this.ID = ID;
        this.name = chuanHoa(name);
        this.uutien = level[Integer.parseInt(ID.substring(2,3))];
        this.totalMark = Double.parseDouble(mark1)*2 + Double.parseDouble(mark2) + Double.parseDouble(mark3) + this.uutien;
    }

    @Override
    public String toString() {
        return ID + " " + name + " " + (uutien == uutien.intValue() ? uutien.intValue() : String.format("%.1f", uutien)) + " " + (totalMark.intValue() == totalMark ? totalMark.intValue() : String.format("%.1f", totalMark));
    }

    @Override
    public int compareTo(ThiSinh o) {
        if(totalMark == o.totalMark){
            return ID.compareTo(o.ID);
        }
        return o.totalMark.compareTo(totalMark);
    }

    public double getTotalMark() {
        return totalMark;
    }
    
}
