package J07084;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.concurrent.TimeUnit;

public class Student implements Comparable<Student>{

    private String name;
    private Long _minutes;
    
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    public Student(String name, String start, String end) throws ParseException {
        this.name = name;
        Long time = sdf.parse(end).getTime() - sdf.parse(start).getTime();
        this._minutes = TimeUnit.MILLISECONDS.toMinutes(time);
    }

    @Override
    public int compareTo(Student o) {
        if(o._minutes == _minutes){
            return name.compareTo(o.name);
        }
        return (int)(o._minutes - _minutes);
    }

    @Override
    public String toString() {
        return name + " " + _minutes;
    }
    
    
    
}
