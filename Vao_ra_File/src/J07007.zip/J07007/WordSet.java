package J07007;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.TreeSet;

class WordSet  {

    private String filename;

    public WordSet(String filename) {
        this.filename = filename;
    }

    @Override
    public String toString() {
        try {
            Scanner sc = new Scanner(new File(filename));
            TreeSet<String> tset = new TreeSet<>();
            while(sc.hasNextLine()){
                String[] tmp = sc.nextLine().trim().toLowerCase().split("\\s+");
                for(String item : tmp){
                    tset.add(item);
                }
            }
            for(String item : tset){
                System.out.println(item);
            }
        } catch (FileNotFoundException ex) { }
        return "";
    }
    
    
    
}
