
package J07010;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class SinhVien {
    
    SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");

    private String msv,name,lop,dob;
    private double gpa;

    public SinhVien(String msv, String name, String lop, String dob, String gpa) throws ParseException {
        this.msv = msv;
        this.name = name;
        this.lop = lop;
        this.dob = sdf.format(sdf.parse(dob));
        this.gpa = Double.parseDouble(gpa);
    }

    @Override
    public String toString() {
        return msv + " " + name + " " + lop + " " + dob + " " + String.format("%.2f", gpa);
    }

    
    
    
    
}
