package J07050;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class J07050 {

    public static void main(String[] args) throws FileNotFoundException {
        
        Scanner sc = new Scanner(new File("MATHANG.in"));
        int t = sc.nextInt(); sc.nextLine();
        int cnt = 1;
        MatHang mh;
        ArrayList<MatHang> arr = new ArrayList<>();
        
        while(t-- > 0){
            mh = new MatHang(String.format("MH%02d", cnt++), sc.nextLine(), sc.nextLine(), sc.nextLine(), sc.nextLine());
            arr.add(mh);
        }
        Collections.sort(arr);
        for(MatHang item : arr){
            System.out.println(item);
        }
    }
    
}
