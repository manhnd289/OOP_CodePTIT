package J07050;

public class MatHang implements Comparable<MatHang>{

    private String ID, name, group;
    private double profit;

    public MatHang(String ID, String name, String group, String buyPrice , String sellPrice) {
        this.ID = ID;
        this.name = name;
        this.group = group;
        this.profit = Double.parseDouble(sellPrice) - Double.parseDouble(buyPrice);
    }

    @Override
    public String toString() {
        return ID + " " + name + " " + group + " " + String.format("%.2f", profit);
    }

    @Override
    public int compareTo(MatHang o) {
        return (int)(o.profit - profit);
    }
    
    
    
}
