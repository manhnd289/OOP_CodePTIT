package J07054;

import java.util.ArrayList;

public class Student implements Comparable<Student>{

    private String Id, name;
    private double ave_mark;
    public static ArrayList<Double> arr_mark = new ArrayList<>();
    
    private static String chuanHoa(String inp){
        String[] tmp = inp.trim().split("\\s+");
        StringBuilder sb = new StringBuilder("");
        for(String item: tmp){
            sb.append(item.substring(0,1).toUpperCase());
            sb.append(item.substring(1).toLowerCase());
            sb.append(" ");
        }
        return sb.toString().trim();
    }

    public Student(String Id, String name, double mark1, int mark2, int mark3) {
        this.Id = Id;
        this.name = chuanHoa(name);
        this.ave_mark = Math.round((mark1*3 + mark2*3 + mark3*2) / 8.0 * 100.0) / 100.0;
        arr_mark.add(this.ave_mark);
    }

    @Override
    public String toString() {
        return Id + " " + name + " " + String.format("%.2f", ave_mark) + " " + (arr_mark.indexOf(ave_mark) + 1);
    }

    @Override
    public int compareTo(Student o) {
        if(o.ave_mark - ave_mark == 0){
            return Id.compareTo(o.Id);
        }return (int)(o.ave_mark - ave_mark) ;
    }
    
    
    
}
